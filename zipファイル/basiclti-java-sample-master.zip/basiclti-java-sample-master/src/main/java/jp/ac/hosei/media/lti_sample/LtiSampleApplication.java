package jp.ac.hosei.media.lti_sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LtiSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LtiSampleApplication.class, args);
	}
}
